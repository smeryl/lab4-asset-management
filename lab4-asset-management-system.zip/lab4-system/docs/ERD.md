# Entity-Relationship Diagram

```mermaid
erDiagram
    PROFILES ||--o{ BORROWING_TRANSACTIONS : "requests (requester_id)"
    PROFILES ||--o{ BORROWING_TRANSACTIONS : "approves (approved_by)"
    PROFILES ||--o{ BORROWING_TRANSACTIONS : "releases (released_by)"
    PROFILES ||--o{ MAINTENANCE_REQUESTS : "submits (requested_by)"
    PROFILES ||--o{ AUDIT_LOGS : "performs (user_id)"
    EQUIPMENT ||--o{ BORROWING_TRANSACTIONS : "is borrowed in"
    EQUIPMENT ||--o{ MAINTENANCE_REQUESTS : "is serviced in"

    PROFILES {
        uuid id PK
        text full_name
        text email
        text role "admin | staff | requester"
        timestamptz created_at
    }

    EQUIPMENT {
        int id PK
        text code UK
        text name
        text category
        text description
        text status "Available|Borrowed|Maintenance|Damaged"
        timestamptz created_at
        timestamptz updated_at
    }

    BORROWING_TRANSACTIONS {
        int id PK
        int equipment_id FK
        uuid requester_id FK
        text status "Pending|Approved|Rejected|Released|Returned|Overdue|Closed"
        text purpose
        timestamptz request_date
        timestamptz due_date
        uuid approved_by FK
        timestamptz approved_at
        uuid released_by FK
        timestamptz released_at
        timestamptz returned_at
        boolean damaged
        text remarks
    }

    MAINTENANCE_REQUESTS {
        int id PK
        int equipment_id FK
        uuid requested_by FK
        text issue_description
        text status "Pending|In Progress|Completed"
        timestamptz created_at
        timestamptz completed_at
    }

    AUDIT_LOGS {
        int id PK
        uuid user_id FK
        text action
        text module
        text record_id
        text description
        timestamptz created_at
    }
```

## Notes
- `PROFILES.id` is a foreign key to Supabase's built-in `auth.users.id`; a
  database trigger (`handle_new_user`) auto-creates the profile row on signup.
- `BORROWING_TRANSACTIONS` has three separate references to `PROFILES`
  (requester, approver, releaser) to preserve full traceability of who did what.
- `AUDIT_LOGS.record_id` is stored as text so it can reference IDs from any
  module (borrowing transaction, maintenance request, user, equipment).

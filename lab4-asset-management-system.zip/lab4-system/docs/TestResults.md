# Functional Test Results

Run these after deploying to GitHub Pages and connecting to your Supabase
project. Fill in **Actual Result** and **Pass/Fail** as you execute each case.
Suggested test accounts: one Administrator, one Staff, one Requester (see
README §6 for how to create them).

| Test ID | Scenario | Steps | Expected Result | Actual Result | Pass/Fail |
|---|---|---|---|---|---|
| TC-A4-01 | Viewer attempts to open Admin page | Log in as Requester; manually try to reach an admin route (e.g. Audit Logs is not in the sidebar; direct route switch shows Access Denied) | Access denied | | |
| TC-A4-02 | Staff submits request | Log in as Staff; go to Equipment; click Request on an Available item | Request saved as Pending | | |
| TC-A4-03 | Administrator approves request | Log in as Admin (different user than requester); go to Approvals; click Approve | Status becomes Approved; audit log entry created | | |
| TC-A4-04 | Administrator rejects request | Log in as Admin; go to Approvals; click Reject on a Pending request | Status becomes Rejected | | |
| TC-A4-05 | Attempt to release rejected request | As Staff/Admin, try to release a transaction that is Rejected (e.g. via direct RPC call) | Operation blocked with BR-A4-07 error | | |
| TC-A4-06 | Release approved equipment | As Staff/Admin, go to Release / Return, click Release on an Approved transaction | Equipment becomes Borrowed | | |
| TC-A4-07 | Return released equipment | As Staff/Admin, click Process Return; submit with/without "damaged" checked | Equipment returns to Available (or Damaged if flagged) | | |
| TC-A4-08 | Check audit log after approval | As Admin, open Audit Logs after approving a request | Approval entry (action = APPROVED) is visible | | |
| TC-A4-09 | Staff attempts restricted delete | Log in as Staff; attempt to delete an equipment record (no delete control shown; verify via direct API call is also blocked by RLS) | Operation blocked | | |
| TC-A4-10 | Logout and open protected page | Log out; try to load the app / a protected route | Redirected to login screen | | |

## Additional rule-level checks (recommended, not in the original 10)

| Scenario | Expected Result | Actual Result | Pass/Fail |
|---|---|---|---|
| Admin tries to approve their own submitted request | Blocked with BR-A4-02 error | | |
| Request equipment that is currently Maintenance or Borrowed | "Request" button hidden in UI; direct insert blocked by trigger (BR-A4-01/09) | | |
| Process return twice on the same transaction | Second attempt blocked with BR-A4-08 error | | |
| Staff submits maintenance request | Equipment status becomes Maintenance; audit entry created | | |

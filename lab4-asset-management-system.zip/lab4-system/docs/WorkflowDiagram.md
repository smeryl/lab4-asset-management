# Borrowing Approval Workflow

```mermaid
stateDiagram-v2
    [*] --> Pending : Requester/Staff submits request\n(create_borrowing_request)\nBR-A4-01, BR-A4-09 checked

    Pending --> Approved : Admin approves\n(approve_borrowing_request)\nBR-A4-02, BR-A4-03
    Pending --> Rejected : Admin rejects\n(reject_borrowing_request)\nBR-A4-02, BR-A4-03

    Approved --> Released : Staff/Admin releases\n(release_equipment)\nBR-A4-04, BR-A4-05
    Rejected --> [*] : Cannot be released\n(BR-A4-07 blocks this path)

    Released --> Returned : Staff/Admin processes return\n(process_return)\nBR-A4-06, BR-A4-08
    Released --> Overdue : due_date passed\n(mark_overdue)
    Overdue --> Returned : Staff/Admin processes return

    Returned --> Closed : Admin closes transaction\n(close_transaction)
    Closed --> [*]

    note right of Approved
        Equipment stays "Available"
        until actually released
    end note

    note right of Released
        Equipment.status = Borrowed
    end note

    note right of Returned
        Equipment.status = Available
        unless damaged = true,
        then Equipment.status = Damaged
    end note
```

## Narrative
1. A **Requester** or **Staff** member submits a borrowing request for a piece of
   equipment that is currently `Available`. The request is created with status
   **Pending**.
2. An **Administrator** reviews the request and either **Approves** or **Rejects**
   it. An admin can never approve/reject their own request.
3. If **Approved**, Staff or Admin **releases** the equipment to the requester.
   The transaction becomes **Released** and the equipment record becomes
   `Borrowed`. A **Rejected** request can never reach this step.
4. If a released item passes its due date without being returned, it can be
   marked **Overdue**.
5. When the item comes back, Staff or Admin **processes the return**. The
   transaction becomes **Returned**; the equipment becomes `Available` again,
   or `Damaged` if the returning staff flags it as damaged. A transaction that
   is already Returned/Closed cannot be processed again.
6. An Administrator may **close** a Returned transaction to mark the full
   lifecycle complete.

Every arrow above corresponds to exactly one Postgres RPC function in
`database/schema.sql`, and every one of those functions writes a row to
`audit_logs` before returning.

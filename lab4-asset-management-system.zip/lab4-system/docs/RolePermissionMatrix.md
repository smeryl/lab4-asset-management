# Role-Permission Matrix

Legend: ✅ Allowed · 🟡 Own records only · ❌ Not allowed

| Function | Administrator | Laboratory Staff | Requester / Viewer |
|---|:---:|:---:|:---:|
| View equipment list | ✅ | ✅ | ✅ |
| Add / edit / delete equipment | ✅ | ❌ | ❌ |
| Submit borrowing request | ✅ | ✅ | ✅ |
| View all borrowing requests | ✅ | ✅ | 🟡 own only |
| Approve / reject borrowing request | ✅ | ❌ | ❌ |
| Release approved equipment | ✅ | ✅ | ❌ |
| Process equipment return | ✅ | ✅ | ❌ |
| Submit maintenance request | ✅ | ✅ | ❌ |
| Complete / close maintenance request | ✅ | ✅ | ❌ |
| Manage user accounts / roles | ✅ | ❌ | ❌ |
| View reports | ✅ | ❌ | ❌ |
| View audit logs | ✅ | ❌ | ❌ |
| View own request history | ✅ | ✅ | ✅ |

## Enforcement mechanism (mapped to implementation)

| Layer | Mechanism |
|---|---|
| Interface | `NAV_BY_ROLE` in `public/js/main.js` renders only the menu items allowed for `profiles.role`; direct route access is re-checked by `renderRoute()`, which shows an **Access Denied** screen for disallowed routes (TC-A4-01). |
| Database | Row Level Security policies on every table (see `database/schema.sql` §3) restrict `SELECT`/`INSERT`/`UPDATE`/`DELETE` by role. State-changing actions (approve, reject, release, return, maintenance) have **no direct UPDATE policy at all** — they can only be performed through `SECURITY DEFINER` RPC functions that re-verify the caller's role from `profiles` before making any change (TC-A4-09). |
| Session | Supabase Auth issues a JWT on login; `auth.uid()` inside every RLS policy and RPC function ties every action back to the authenticated user, which is what makes the audit trail trustworthy. Logging out clears the session and any protected route redirects back to the login screen (TC-A4-10). |

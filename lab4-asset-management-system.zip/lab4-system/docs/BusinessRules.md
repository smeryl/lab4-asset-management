# Business Rules — Implementation Reference

| ID | Rule | Enforced by |
|---|---|---|
| BR-A4-01 | Only available equipment may be requested | `trg_check_equipment_available` trigger on `borrowing_transactions` (before insert) |
| BR-A4-02 | Staff/Admin cannot approve or reject their own request | `approve_borrowing_request` / `reject_borrowing_request`: raises exception if `requester_id = auth.uid()` |
| BR-A4-03 | Only Administrator may approve or reject requests | `approve_borrowing_request` / `reject_borrowing_request`: raises exception unless `is_admin()` |
| BR-A4-04 | Only Approved requests may be released | `release_equipment`: raises exception unless current status is `Approved` |
| BR-A4-05 | Released equipment becomes Borrowed | `release_equipment`: sets `equipment.status = 'Borrowed'` |
| BR-A4-06 | Returned equipment becomes Available unless damaged | `process_return`: sets `equipment.status = 'Available'` or `'Damaged'` based on `p_damaged` |
| BR-A4-07 | Rejected requests cannot be released | `release_equipment`: explicitly raises exception when status is `Rejected`, before the generic Approved check |
| BR-A4-08 | Returned transactions cannot be processed twice | `process_return`: raises exception if status is already `Returned` or `Closed` |
| BR-A4-09 | Equipment under Maintenance cannot be borrowed | Same `trg_check_equipment_available` trigger — only `Available` passes |
| BR-A4-10 | Sensitive operations must be logged | Every RPC (`create_borrowing_request`, `approve_borrowing_request`, `reject_borrowing_request`, `release_equipment`, `process_return`, `close_transaction`, `submit_maintenance_request`, `complete_maintenance`) calls `log_audit()` before returning |

## Why enforcement lives in the database, not just the UI

All ten rules are implemented as **Postgres triggers or `SECURITY DEFINER`
functions**, not as JavaScript `if` statements. The JavaScript in
`public/js/main.js` also checks these conditions so the interface feels
responsive and shows the right buttons — but that is a UX convenience, not the
real guard. Even if a user opened the browser dev tools and called
`supabase.rpc(...)` directly with different arguments, or tried a raw
`UPDATE` on `borrowing_transactions`, the request would still be rejected
because:

- There is **no RLS `UPDATE` policy** granted to regular users on
  `borrowing_transactions` — direct updates are refused outright.
- Every RPC function re-checks the caller's role via `is_admin()` /
  `is_staff()` (which read `profiles.role` using `auth.uid()` from the
  verified JWT) and re-checks the record's current status before mutating
  anything.

This is what satisfies the lab objective: *"Verify that authorization is
enforced at both interface and database levels."*

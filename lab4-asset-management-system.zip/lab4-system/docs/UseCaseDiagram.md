# Use Case Diagram

```mermaid
flowchart LR
    Admin([Administrator])
    Staff([Laboratory Staff])
    Requester([Requester / Viewer])

    subgraph System["Laboratory Asset and Service Management System"]
        UC1((Manage Users))
        UC2((Manage Equipment))
        UC3((View Equipment))
        UC4((Submit Borrowing Request))
        UC5((Approve / Reject Request))
        UC6((Release Equipment))
        UC7((Process Return))
        UC8((Submit Maintenance Request))
        UC9((Complete Maintenance))
        UC10((View Own Request History))
        UC11((View Reports))
        UC12((View Audit Logs))
        UC13((Login / Logout))
    end

    Admin --> UC1
    Admin --> UC2
    Admin --> UC3
    Admin --> UC5
    Admin --> UC6
    Admin --> UC7
    Admin --> UC9
    Admin --> UC11
    Admin --> UC12
    Admin --> UC13

    Staff --> UC3
    Staff --> UC4
    Staff --> UC6
    Staff --> UC7
    Staff --> UC8
    Staff --> UC9
    Staff --> UC10
    Staff --> UC13

    Requester --> UC3
    Requester --> UC4
    Requester --> UC10
    Requester --> UC13

    UC5 -.include.-> UC12
    UC6 -.include.-> UC12
    UC7 -.include.-> UC12
    UC1 -.include.-> UC12
```

## Actor Summary
| Actor | Description |
|---|---|
| Administrator | Full control: user/equipment management, approvals, maintenance oversight, reports, audit logs |
| Laboratory Staff | Operational tasks: view equipment, create/release/return transactions, submit maintenance requests |
| Requester / Viewer | End user: browse equipment, submit borrowing requests, track own request status |
